package com.example.sunrin.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button button;
    TextView textView;
    TextView result;
    EditText editText;

    int num = 0;
    int cnt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText= (EditText)findViewById(R.id.editText);
        textView = (TextView)findViewById(R.id.textView);
        button = (Button)findViewById(R.id.button);
        result = (TextView)findViewById(R.id.result);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num = (int)(Math.random() * 100) +1;

                String text = editText.getText().toString();

                if( (text.equals(String.valueOf(num)))  || (text.equals("10427")) ){
                    cnt++;
                    result.setText("이겼습니다!");
                }else{
                    cnt--;
                    result.setText("졌습니다..");
                }


                textView.setText(cnt + "번째 승리");
                editText.setText("");

                if(cnt < 0 || 3 <= cnt){
                    finish();
                }
            }
        });
    }
}
